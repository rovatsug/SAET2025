#include <stdio.h>

int main() {
    int n;
    scanf("%d",&n);
    int v[n];
    for (int i=0;i<n;i++)
        scanf("%d",&v[i]);

    // bubble?
    for (int i=0;i<n;i++)
        for (int j=0;j+1<n;j++)
            if (v[j] < v[j+1]) {
                v[j] = v[j+1];
                v[j+1] = v[j];
            }
    for (int i=0;i<n;i++)
        printf("%d ",v[i]);
    printf("\n");

    return 0;
}
