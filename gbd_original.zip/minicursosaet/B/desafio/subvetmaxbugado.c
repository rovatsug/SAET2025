#include <stdio.h>

int main() {

    int n, k, menor;
    int v[100];
    int pfprod[100];

    scanf("%d %d",&n, &k);
    for (int i=0;i<n;i++)
        scanf("%d",&v[i]);
    for (int i=0;i<n;i++)
        pfprod[i] = pfprod[i-1] * v[i];

    for (int i=k;i<n;i++) {
        int subvetor = pfprod[i] / pfprod[i-k-1];
        if (subvetor < menor)
            menor = subvetor;
    }
    printf("%d\n",menor);

    return 0;
}
